CREATE TABLE `dataset` (
  `id_dataset` int(11) NOT NULL,
  `id_karyawan` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE karyawan (
  id_karyawan VARCHAR(3) NOT NULL,
  nidn_nipy VARCHAR(255) NOT NULL,
  nama_lengkap VARCHAR(255) NOT NULL,
  jabatan VARCHAR(255) NOT NULL,
  jenis_kelamin VARCHAR(12) NOT NULL
);

ALTER TABLE `dataset`
  ADD PRIMARY KEY (`id_dataset`);
  
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);


CREATE TABLE absensi_masuk (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  karyawan_id VARCHAR(3) NOT NULL,
  waktu DATE NOT NULL,
  waktu_masuk DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `waktu_masuk` (`waktu_masuk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE absensi_pulang (
  id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  karyawan_id VARCHAR(3) NOT NULL,
  waktu DATE NOT NULL,
  waktu_pulang DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY `waktu_pulang` (`waktu_pulang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;