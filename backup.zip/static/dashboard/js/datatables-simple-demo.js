document.addEventListener('DOMContentLoaded', function () {
    const dataTabel = document.getElementById('datatablesSimple');
    const exportButton = document.getElementById('Print');

    // Inisialisasi Simple-DataTables
    const table = new simpleDatatables.DataTable(dataTabel);
});
