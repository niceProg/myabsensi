-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 27 Jul 2023 pada 01.58
-- Versi server: 11.0.2-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myabsensi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absen_masuk`
--

CREATE TABLE `absen_masuk` (
  `id` int(11) NOT NULL,
  `karyawan_id` varchar(3) NOT NULL,
  `waktu` date NOT NULL,
  `waktu_masuk` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `absen_masuk`
--

INSERT INTO `absen_masuk` (`id`, `karyawan_id`, `waktu`, `waktu_masuk`) VALUES
(38, '2', '2023-07-26', '2023-07-26 07:55:45'),
(39, '1', '2023-07-25', '2023-07-25 15:48:58'),
(40, '1', '2023-07-26', '2023-07-26 15:48:58'),
(41, '1', '2023-07-27', '2023-07-27 15:48:58'),
(42, '2', '2023-07-27', '2023-07-27 07:55:45'),
(43, '3', '2023-07-27', '2023-07-27 08:07:41');

-- --------------------------------------------------------

--
-- Struktur dari tabel `absen_pulang`
--

CREATE TABLE `absen_pulang` (
  `id` int(11) NOT NULL,
  `karyawan_id` varchar(3) NOT NULL,
  `waktu` date NOT NULL,
  `waktu_pulang` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `absen_pulang`
--

INSERT INTO `absen_pulang` (`id`, `karyawan_id`, `waktu`, `waktu_pulang`) VALUES
(12, '1', '2023-07-25', '2023-07-25 23:57:46'),
(13, '1', '2023-07-26', '2023-07-26 23:57:46'),
(14, '1', '2023-07-27', '2023-07-27 23:57:46'),
(15, '3', '2023-07-27', '2023-07-27 08:11:37'),
(16, '2', '2023-07-27', '2023-07-27 08:56:15');

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', 'admin', 'admin@example.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `dataset`
--

CREATE TABLE `dataset` (
  `id_dataset` int(11) NOT NULL,
  `id_karyawan` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `dataset`
--

INSERT INTO `dataset` (`id_dataset`, `id_karyawan`) VALUES
(1, '1'),
(2, '1'),
(3, '1'),
(4, '1'),
(5, '1'),
(6, '1'),
(7, '1'),
(8, '1'),
(9, '1'),
(10, '1'),
(11, '1'),
(12, '1'),
(13, '1'),
(14, '1'),
(15, '1'),
(16, '1'),
(17, '1'),
(18, '1'),
(19, '1'),
(20, '1'),
(21, '1'),
(22, '1'),
(23, '1'),
(24, '1'),
(25, '1'),
(26, '1'),
(27, '1'),
(28, '1'),
(29, '1'),
(30, '1'),
(31, '1'),
(32, '1'),
(33, '1'),
(34, '1'),
(35, '1'),
(36, '1'),
(37, '1'),
(38, '1'),
(39, '1'),
(40, '1'),
(41, '1'),
(42, '1'),
(43, '1'),
(44, '1'),
(45, '1'),
(46, '1'),
(47, '1'),
(48, '1'),
(49, '1'),
(50, '1'),
(51, '2'),
(52, '2'),
(53, '2'),
(54, '2'),
(55, '2'),
(56, '2'),
(57, '2'),
(58, '2'),
(59, '2'),
(60, '2'),
(61, '2'),
(62, '2'),
(63, '2'),
(64, '2'),
(65, '2'),
(66, '2'),
(67, '2'),
(68, '2'),
(69, '2'),
(70, '2'),
(71, '2'),
(72, '2'),
(73, '2'),
(74, '2'),
(75, '2'),
(76, '2'),
(77, '2'),
(78, '2'),
(79, '2'),
(80, '2'),
(81, '2'),
(82, '2'),
(83, '2'),
(84, '2'),
(85, '2'),
(86, '2'),
(87, '2'),
(88, '2'),
(89, '2'),
(90, '2'),
(91, '2'),
(92, '2'),
(93, '2'),
(94, '2'),
(95, '2'),
(96, '2'),
(97, '2'),
(98, '2'),
(99, '2'),
(100, '2'),
(101, '3'),
(102, '3'),
(103, '3'),
(104, '3'),
(105, '3'),
(106, '3'),
(107, '3'),
(108, '3'),
(109, '3'),
(110, '3'),
(111, '3'),
(112, '3'),
(113, '3'),
(114, '3'),
(115, '3'),
(116, '3'),
(117, '3'),
(118, '3'),
(119, '3'),
(120, '3'),
(121, '3'),
(122, '3'),
(123, '3'),
(124, '3'),
(125, '3'),
(126, '3'),
(127, '3'),
(128, '3'),
(129, '3'),
(130, '3'),
(131, '3'),
(132, '3'),
(133, '3'),
(134, '3'),
(135, '3'),
(136, '3'),
(137, '3'),
(138, '3'),
(139, '3'),
(140, '3'),
(141, '3'),
(142, '3'),
(143, '3'),
(144, '3'),
(145, '3'),
(146, '3'),
(147, '3'),
(148, '3'),
(149, '3'),
(150, '3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `karyawan`
--

CREATE TABLE `karyawan` (
  `id_karyawan` varchar(3) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `jabatan` varchar(255) NOT NULL,
  `nidn_nipy` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nama_lengkap`, `jabatan`, `nidn_nipy`, `jenis_kelamin`) VALUES
('1', 'Wisnu Yumna Yudhanta', 'Dosen Tetap Teknik Informatika', '1909122', 'Laki-laki'),
('2', 'M Nursyams Hilmi S.Pd M.M', 'Direktur', '0623096701', 'Laki-laki'),
('3', 'Fahrudin, S.Kom, M.Kom', 'Kaprodi D-III Teknik Informatika', '0610016802', 'Laki-laki');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `absen_masuk`
--
ALTER TABLE `absen_masuk`
  ADD PRIMARY KEY (`id`),
  ADD KEY `waktu_masuk` (`waktu_masuk`);

--
-- Indeks untuk tabel `absen_pulang`
--
ALTER TABLE `absen_pulang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `waktu_pulang` (`waktu_pulang`);

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `dataset`
--
ALTER TABLE `dataset`
  ADD PRIMARY KEY (`id_dataset`);

--
-- Indeks untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `absen_masuk`
--
ALTER TABLE `absen_masuk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT untuk tabel `absen_pulang`
--
ALTER TABLE `absen_pulang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
