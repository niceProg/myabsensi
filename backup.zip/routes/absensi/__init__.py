from flask import Blueprint, render_template, session, Response
from flask import current_app as app
from flask import request, flash, redirect, url_for, jsonify
import mysql.connector
from flask_cors import CORS
import os
import cv2
from PIL import Image
import numpy as np
import logging
from functools import wraps
from routes.absensi.recognize_masuk import recognize_masuk
from routes.absensi.recognize_pulang import recognize_pulang

Absensi = Blueprint (
    name='Absensi',
    import_name=__name__,
    url_prefix='/absensi',
    template_folder='../../templates/'
)

db = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="root",
        database="myabsensi"
    )
cursor = db.cursor()

@Absensi.route('/masuk')
def recog_masuk():
    return Response(recognize_masuk(),
    mimetype='multipart/x-mixed-replace; boundary=frame'
)
@Absensi.route('/pulang')
def recog_pulang():
    return Response(recognize_pulang(),
    mimetype='multipart/x-mixed-replace; boundary=frame'
)

@Absensi.route('/')
def absensi():

    return render_template(
        title="Absensi | My Absensi",
        template_name_or_list="absen.html"
    )

# @Absensi.route('/check_attendance', methods=['GET'])
# def check_attendance():
#     attendance_detected = app.config['attendance_detected']

#     if attendance_detected:
#         return jsonify({'attendance_detected': True})

#     return jsonify({'attendance_detected': False})
    # if justscanned:
    #     performAction()

    # return jsonify({"attendance_detected": attendance_detected})

def mark_attendance():
    attendance_detected = app.config['attendance_detected']

    if not attendance_detected:
        id_karyawan = request.json.get('id_karyawan')

        cursor.execute("SELECT id_karyawan FROM absensi WHERE id_karyawan = %s", (id_karyawan,))
        existing_attendance = cursor.fetchone()

        if existing_attendance:
            flash('Karyawan sudah absen sebelumnya', 'error')
        else:
            app.config['attendance_detected'] = True
            flash('Absen berhasil!', 'success')

    return redirect(url_for('Absensi.absensi'))


