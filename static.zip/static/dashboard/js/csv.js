document.addEventListener('DOMContentLoaded', function () {
    const dataTabel = document.getElementById('datatablesSimple');
    const exportButton = document.getElementById('CSV');

    // Inisialisasi Simple-DataTables
    const table = new simpleDatatables.DataTable(dataTabel);

    // Tambahkan event listener pada tombol ekspor
    exportButton.addEventListener('click', function () {
        exportToCSV(table);
    });

    function exportToCSV(table) {
        const rows = Array.from(dataTabel.querySelectorAll('tbody tr'));
        const headers = Array.from(dataTabel.querySelectorAll('thead th')).map((header) => header.innerText);
        const csvContent = [headers.join(',')];

        rows.forEach(function (row) {
            const rowData = Array.from(row.querySelectorAll('td'))
                .map((cell) => `"${cell.innerText}"`)
                .join(',');
            csvContent.push(rowData);
        });

        const csvData = csvContent.join('\n');
        const filename = 'data.csv';

        // Buat elemen link untuk mengunduh file CSV
        const link = document.createElement('a');
        link.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvData);
        link.download = filename;

        // Simulasikan klik pada link untuk mengunduh file CSV
        link.click();
    }
});
