document.addEventListener('DOMContentLoaded', function () {
    const dataTabel = document.getElementById('datatablesSimple');
    const exportButton = document.getElementById('Print');

    // Inisialisasi Simple-DataTables
    const table = new simpleDatatables.DataTable(dataTabel);

    // Tambahkan event listener pada tombol print
    exportButton.addEventListener('click', function () {
        printCSV(table);
    });

    // Fungsi untuk mencetak data dalam format CSV
    function printCSV(table) {
        const rows = Array.from(dataTabel.querySelectorAll('tbody tr'));
        const headers = Array.from(dataTabel.querySelectorAll('thead th')).map((header) => header.innerText);
        const csvContent = [headers.join('\t')];

        rows.forEach(function (row) {
            const rowData = Array.from(row.querySelectorAll('td')).map((cell) => cell.innerText);
            csvContent.push(rowData.join('\t'));
        });

        const csvData = csvContent.join('\n');

        // Buat elemen <pre> untuk menampilkan data CSV dengan format
        const preElement = document.createElement('pre');
        preElement.innerText = csvData;

        // Buka jendela cetak
        const printWindow = window.open('', '_blank');
        printWindow.document.open();
        printWindow.document.write('<html><head><title>Data CSV</title></head><body>');
        printWindow.document.write('<h2>Laporan Kehadiran</h2>');
        printWindow.document.write('<p>Klik kanan pada halaman ini dan pilih "Print" untuk mencetak data.</p>');
        printWindow.document.write('<hr>');
        printWindow.document.write(preElement.outerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();

        // Fokus pada jendela cetak dan jalankan fungsi cetak
        printWindow.focus();
        printWindow.print();
    }
});
